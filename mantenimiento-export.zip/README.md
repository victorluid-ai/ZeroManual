# Mantenimiento

Plataforma de **mantenimiento preventivo** para grupos de restauración.
Inventario de equipos por restaurante, calendario de revisiones y sistema de alarmas.
Backend Python (FastAPI + Jinja2) y base de datos **Supabase (PostgreSQL)**.

## Arranque rápido (demo local)

```bash
python -m pip install -e ".[dev]"
export MANTENIMIENTO_DEMO_MODE=true
python -m app
```

Abre http://localhost:8100

## Supabase

1. Crea un proyecto en [Supabase](https://supabase.com).
2. En el SQL Editor, ejecuta en orden:
   - `supabase/migrations/001_initial_schema.sql`
   - `supabase/seed.sql`
3. Copia `.env.example` a `.env` y rellena las claves:

```bash
export SUPABASE_URL=https://xxxx.supabase.co
export SUPABASE_SERVICE_ROLE_KEY=eyJ...
unset MANTENIMIENTO_DEMO_MODE
python -m app
```

## Modelo de datos

| Tabla | Uso |
|-------|-----|
| `groups` | Grupo de restauración (tenant) |
| `restaurants` | Locales del grupo |
| `equipment_types` | Catálogo (horno, Josper, combi, cámara…) |
| `equipment` | Máquinas físicas por restaurante |
| `maintenance_plans` | Planes preventivos con `next_due_at` |
| `maintenance_logs` | Historial de intervenciones |
| `alarms` | Alarmas abiertas / reconocidas / resueltas |

## Rutas

| URL | Función |
|-----|---------|
| `/` | Landing |
| `/panel` | Dashboard operativo |
| `/restaurantes` | Alta y listado de locales |
| `/equipos` | Inventario + alta de máquinas |
| `/preventivos` | Calendario y cierre de intervenciones |
| `/alarmas` | Sistema de alarmas |
| `/salud` | Healthcheck JSON |

## Tests

```bash
MANTENIMIENTO_DEMO_MODE=true python -m pytest -q
```
